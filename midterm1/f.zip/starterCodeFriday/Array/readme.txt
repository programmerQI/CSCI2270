use for loop travels all the element in the array
check if the element mod 2 == 1, add it to the oddarr, else put it in to 
